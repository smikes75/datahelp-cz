import { useTranslation } from 'react-i18next';

export interface SEOConfig {
  title: string;
  description: string;
  keywords: string;
  image?: string;
  canonical?: string;
  schema?: Record<string, unknown>;
}

// Base schema for organization
const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "DataHelp.eu",
  "url": "https://datahelp.eu",
  "logo": "https://datahelp.eu/DataHelp.eu.svg",
  "foundingDate": "2003",
  "description": "Profesionální záchrana dat s více než 20 lety zkušeností - HDD, SSD, RAID recovery",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "Jirsíkova 541/1",
    "addressLocality": "Praha",
    "postalCode": "186 00",
    "addressCountry": "CZ"
  },
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "+420-775-220-440",
    "contactType": "customer service",
    "availableLanguage": "cs",
    "areaServed": ["CZ", "SK", "DE", "AT"]
  },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.9",
    "reviewCount": "150",
    "bestRating": "5",
    "worstRating": "1"
  }
};

// Enhanced SEO configurations for each page
const seoConfigs: Record<string, SEOConfig> = {
  home: {
    title: "DataHelp.eu - Profesionální záchrana dat | HDD, SSD, RAID obnova",
    description: "Profesionální služby záchrany dat s více než 20 lety zkušeností. Specializujeme se na obnovu HDD, SSD a RAID systémů. Garance: žádná data = žádná platba.",
    keywords: "záchrana dat, obnova dat, HDD recovery, SSD recovery, RAID recovery, profesionální záchrana dat Praha, oprava pevného disku, obnova smazaných dat",
    schema: {
      ...organizationSchema,
      "@type": ["Organization", "LocalBusiness"],
      "priceRange": "KčKč",
      "paymentAccepted": "Cash, Credit Card, Bank Transfer",
      "currenciesAccepted": "EUR, CZK"
    }
  },
  services: {
    title: "Služby záchrany dat | HDD, SSD, RAID, NAS obnova | DataHelp.eu",
    description: "Komplexní služby záchrany dat pro HDD, SSD, RAID systémy a firemní řešení. Specializovaná laboratoř s více než 20 lety zkušeností. Bezplatná diagnostika.",
    keywords: "služby záchrany dat, hdd obnova, ssd recovery, raid systémy, nas recovery, firemní řešení, laboratoř záchrany dat",
    schema: {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "Data Recovery Services",
      "provider": organizationSchema,
      "serviceType": "Data Recovery",
      "areaServed": ["CZ", "DE", "AT", "SK", "IT"],
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Data Recovery Services",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "HDD Data Recovery",
              "description": "Professional hard drive data recovery"
            }
          },
          {
            "@type": "Offer", 
            "itemOffered": {
              "@type": "Service",
              "name": "SSD Data Recovery",
              "description": "SSD and flash memory data recovery"
            }
          }
        ]
      }
    }
  },
  about: {
    title: "O nás | 20+ let zkušeností v záchraně dat | DataHelp.eu",
    description: "Profesionální záchrana dat s více než 20 lety zkušeností. Specializovaná laboratoř, certifikovaní technici a nejmodernější technologie pro obnovu dat.",
    keywords: "o datahelp, zkušenosti obnova dat, expertní tým, laboratoř pro záchranu dat, certifikovaní specialisté, bezpečnost dat",
    schema: {
      "@context": "https://schema.org",
      "@type": "AboutPage",
      "mainEntity": organizationSchema
    }
  },
  contact: {
    title: "Kontakt | 24/7 pohotovost | Záchrana dat Praha | DataHelp.eu",
    description: "Kontaktujte naše experty na záchranu dat. Dostupná 24/7 pohotovostní služba. Profesionální laboratoř záchrany dat v Praze.",
    keywords: "kontakt datahelp, záchrana dat kontakt, pohotovost záchrana dat, laboratoř Praha",
    schema: {
      "@context": "https://schema.org",
      "@type": "ContactPage",
      "mainEntity": organizationSchema
    }
  },
  pricing: {
    title: "Ceník záchrany dat | Transparentní ceny | Žádná data = žádná platba",
    description: "Transparentní ceník služeb záchrany dat. Platíte pouze za úspěšnou záchranu. Bezplatná vstupní diagnostika. Ceny od 6 250 Kč pro SSD a 8 750 Kč pro HDD.",
    keywords: "ceník záchrana dat, cena obnova dat, hdd recovery cena, ssd recovery cena, raid recovery cena, diagnostika zdarma",
    schema: {
      "@context": "https://schema.org",
      "@type": "PriceSpecification",
      "description": "Data Recovery Pricing",
      "priceCurrency": "EUR",
      "eligibleRegion": ["CZ", "DE", "AT", "SK"]
    }
  },
  faq: {
    title: "Často kladené otázky | FAQ záchrana dat | DataHelp.eu",
    description: "Odpovědi na nejčastější otázky o službách záchrany dat. Zjistěte více o našem procesu, cenách a bezpečnostních opatřeních.",
    keywords: "faq záchrana dat, otázky obnova dat, jak funguje záchrana dat, bezpečnost dat",
    schema: {
      "@context": "https://schema.org",
      "@type": "FAQPage"
    }
  },
  blog: {
    title: "Blog | Novinky a tipy o záchraně dat | DataHelp.eu",
    description: "Aktuální články, tipy a novinky ze světa záchrany dat. Průvodce, case studies a odborné rady od profesionálů.",
    keywords: "záchrana dat blog, data recovery články, tipy obnova dat, průvodce záchrana dat, case studies",
    schema: {
      "@context": "https://schema.org",
      "@type": "Blog",
      "name": "DataHelp.eu Blog",
      "description": "Blog o záchraně dat a data recovery",
      "publisher": organizationSchema
    }
  }
};

// Hook for using SEO configuration
export function useSEO(page: keyof typeof seoConfigs) {
  const { t } = useTranslation();  const baseConfig = seoConfigs[page];

  // Get translated values if they exist
  const translatedConfig = {
    title: t(`seo.${page}.title`, baseConfig.title),
    description: t(`seo.${page}.description`, baseConfig.description),
    keywords: t(`seo.${page}.keywords`, baseConfig.keywords),
  };

  return {
    ...baseConfig,
    ...translatedConfig,
    canonical: `https://datahelp.eu/${page === 'home' ? '' : page}`
  };
}

// Generate breadcrumb schema
export const generateBreadcrumbSchema = (items: Array<{name: string, url: string}>) => ({
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": items.map((item, index) => ({
    "@type": "ListItem",
    "position": index + 1,
    "name": item.name,
    "item": item.url
  }))
});

// Generate article schema for blog posts
export const generateArticleSchema = (
  title: string,
  description: string,
  image: string,
  datePublished?: string,
  dateModified?: string,
  author?: string
) => ({
  "@context": "https://schema.org",
  "@type": "TechArticle",
  "headline": title,
  "description": description,
  "image": {
    "@type": "ImageObject",
    "url": image,
    "width": 1200,
    "height": 630
  },
  "author": {
    "@type": "Person",
    "name": author || "DataHelp.eu Team",
    "url": "https://datahelp.eu/about"
  },
  "publisher": {
    "@type": "Organization",
    "name": "DataHelp.eu",
    "logo": {
      "@type": "ImageObject",
      "url": "https://datahelp.eu/DataHelp.eu.svg"
    }
  },
  "datePublished": datePublished || new Date().toISOString(),
  "dateModified": dateModified || new Date().toISOString(),
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://datahelp.eu/blog"
  },
  "articleSection": "Data Recovery",
  "inLanguage": "cs"
});