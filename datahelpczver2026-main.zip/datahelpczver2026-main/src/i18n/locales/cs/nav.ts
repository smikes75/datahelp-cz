export const nav = {
  home: 'Domů',
  services: 'Služby',
  priceCalculator: 'Zjistit cenu',
  about: 'O nás',
  technology: 'Technologie',
  pricing: 'Ceník',
  blog: 'Blog',
  contact: 'Kontakt'
};