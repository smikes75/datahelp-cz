export const admin = {
  login: 'Přihlášení',
  logout: 'Odhlásit se',
  password: 'Heslo',
  signIn: 'Přihlásit se',
  signingIn: 'Přihlašování...',
  contactForms: 'Kontaktní formuláře',
  created: 'Vytvořeno',
  status: 'Stav',
  actions: 'Akce',
  processed: 'Zpracováno',
  new: 'Nové',
  markAsProcessed: 'Označit jako zpracované',
  markAsNew: 'Označit jako nové'
};