export const accessibility = {
  skipToMain: 'Přeskočit na hlavní obsah',
  backToTop: 'Zpět nahoru',
  selectLanguage: 'Vybrat jazyk',
  toggleMenu: 'Otevřít/zavřít menu',
  socialMedia: {
    instagram: 'Instagram',
    facebook: 'Facebook'
  }
};