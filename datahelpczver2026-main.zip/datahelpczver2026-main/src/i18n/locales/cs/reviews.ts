export const reviews = {
  title: 'Napsali jste o nás',
  review1: 'Profesionální přístup a rychlé řešení. Obnovili kritická data z našich serverů.',
  review2: 'Vynikající komunikace a perfektní výsledky. Doporučujeme pro všechny firmy.',
  review3: 'Obnovili naši databázi po ransomware útoku. Skvělá práce!'
};