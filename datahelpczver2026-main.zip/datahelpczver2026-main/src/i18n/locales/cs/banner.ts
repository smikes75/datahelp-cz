export const banner = {
  noPayment: 'Šťastný nový rok 2025',
  freeConsultation: 'Happy New Year 2025',
  secureRecovery: 'Frohes neues Jahr 2025',
  certified: 'Felice Anno Nuovo 2025'
};