export const hero = {
  title: 'Obnova dat\npro firmy i jednotlivce',
  subtitle: 'Specializujeme se na záchranu dat z poškozených médií již více než 20 let.',
  consultation: 'Bezplatná konzultace',
  getPrice: 'Zjistit cenu',
  orderDiagnostics: 'Objednat diagnostiku',
  ourServices: 'Služby',
  security: 'Garance bezpečnosti',
  securityDesc: 'Možnost NDA',
  technology: 'Moderní technologie',
  technologyDesc: 'Špičkové vybavení',
  experience: '20 let zkušeností',
  experienceDesc: 'Více jak 55.000 vyřešených zakázek'
};