export const gallery = {
  title: 'Naše firma',
  cleanRoom: 'Čistá místnost',
  diagnostics: 'Diagnostika',
  serverRoom: 'Serverovna',
  dataCenter: 'Datové centrum',
  aboutTitle: 'DataHelp',
  aboutDescription: 'Takto to u nás vypadá',
  aboutTeam: 'To jsme my',
  aboutWorkspace: 'Moderní pracoviště',
  aboutQuality: 'Kontrola kvality',
  aboutPrecision: 'Přesnost a detail',
  aboutTechnology: 'Pokročilé technologie',
  aboutLab: 'Laboratorní vybavení',
  aboutExpertise: 'Měření a diagnostika',
  aboutInnovation: 'Inovace a rozvoj',
  loadMore: 'Zobrazit další'
};