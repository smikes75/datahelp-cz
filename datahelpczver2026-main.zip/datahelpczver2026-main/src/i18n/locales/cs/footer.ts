export const footer = {
  privacy: 'Ochrana soukromí',
  terms: 'Obchodní podmínky',
  cookies: 'Cookies',
  legal: 'Právní informace',
  legalInfo: 'Právní informace',
  followUs: 'Sledujte nás'
};